const postContainer = document.getElementById("postContainer");
const searchInput = document.getElementById("searchInput");
const noResults = document.getElementById("noResults");
const categoryButtons = document.querySelectorAll(".category");
const themeBtn = document.getElementById("themeBtn");

const postModal = document.getElementById("postModal");
const readModal = document.getElementById("readModal");
const adminBtn = document.getElementById("adminBtn");
const closeModal = document.getElementById("closeModal");
const closeReadModal = document.getElementById("closeReadModal");

const postForm = document.getElementById("postForm");
const postId = document.getElementById("postId");
const titleInput = document.getElementById("titleInput");
const categoryInput = document.getElementById("categoryInput");
const descriptionInput = document.getElementById("descriptionInput");
const contentInput = document.getElementById("contentInput");

const modalTag = document.getElementById("modalTag");
const modalTitle = document.getElementById("modalTitle");

let selectedCategory = "all";

const defaultPosts = [
  {
    id: 1,
    title: "My First Week of Learning C",
    category: "coding",
    description: "What I learned about variables, loops, functions and pointers as a beginner.",
    content: "This week I started learning C programming.\n\nI learned about variables, loops, functions and pointers. The biggest lesson was that understanding the basics is more important than trying to memorize everything.",
    date: "Sep 28, 2026"
  },
  {
    id: 2,
    title: "How I Survived a Busy Semester",
    category: "college",
    description: "A few simple lessons that helped me manage classes, assignments and exams.",
    content: "College can get busy very quickly.\n\nI found that breaking large subjects into smaller topics makes studying much easier. I also learned that starting early reduces a lot of stress.",
    date: "Sep 20, 2026"
  },
  {
    id: 3,
    title: "Why Starting Small Actually Works",
    category: "life",
    description: "You don't need a perfect plan. Sometimes the best way forward is simply to start.",
    content: "Starting something new can feel difficult because we want everything to be perfect.\n\nBut small progress is still progress. Building one small project taught me more than waiting for the perfect idea ever could.",
    date: "Sep 12, 2026"
  }
];

let posts = JSON.parse(localStorage.getItem("myBlogPosts")) || defaultPosts;

function savePosts() {
  localStorage.setItem("myBlogPosts", JSON.stringify(posts));
}

function escapeHTML(text) {
  const div = document.createElement("div");
  div.textContent = text;
  return div.innerHTML;
}

function renderPosts() {
  postContainer.innerHTML = "";

  const searchText = searchInput.value.toLowerCase().trim();

  const filtered = posts.filter(post => {
    const matchesCategory =
      selectedCategory === "all" || post.category === selectedCategory;

    const matchesSearch =
      post.title.toLowerCase().includes(searchText) ||
      post.description.toLowerCase().includes(searchText) ||
      post.content.toLowerCase().includes(searchText);

    return matchesCategory && matchesSearch;
  });

  noResults.style.display = filtered.length ? "none" : "block";

  filtered.forEach(post => {
    const icon = {
      coding: "</>",
      college: "📚",
      life: "☕"
    }[post.category];

    const card = document.createElement("article");
    card.className = "post-card";

    card.innerHTML = `
      <div class="post-image ${post.category}">${icon}</div>
      <div class="post-content">
        <span class="category-label">${escapeHTML(post.category)}</span>
        <h3>${escapeHTML(post.title)}</h3>
        <p>${escapeHTML(post.description)}</p>

        <div class="post-footer">
          <span>${escapeHTML(post.date)}</span>
        </div>

        <div class="post-actions">
          <button class="read-btn" onclick="readPost(${post.id})">Read</button>
          <button class="edit-btn" onclick="editPost(${post.id})">Edit</button>
          <button class="delete-btn" onclick="deletePost(${post.id})">Delete</button>
        </div>
      </div>
    `;

    postContainer.appendChild(card);
  });
}

function openNewPost() {
  postForm.reset();
  postId.value = "";
  modalTag.textContent = "CREATE POST";
  modalTitle.textContent = "Write a new post";
  postModal.classList.add("show");
  titleInput.focus();
}

function editPost(id) {
  const post = posts.find(p => p.id === id);
  if (!post) return;

  postId.value = post.id;
  titleInput.value = post.title;
  categoryInput.value = post.category;
  descriptionInput.value = post.description;
  contentInput.value = post.content;

  modalTag.textContent = "EDIT POST";
  modalTitle.textContent = "Edit your post";
  postModal.classList.add("show");
  titleInput.focus();
}

function deletePost(id) {
  const post = posts.find(p => p.id === id);

  if (!post) return;

  const confirmed = confirm(
    `Delete "${post.title}"? This cannot be undone.`
  );

  if (confirmed) {
    posts = posts.filter(p => p.id !== id);
    savePosts();
    renderPosts();
  }
}

function readPost(id) {
  const post = posts.find(p => p.id === id);
  if (!post) return;

  document.getElementById("readCategory").textContent = post.category;
  document.getElementById("readTitle").textContent = post.title;
  document.getElementById("readDate").textContent = post.date;
  document.getElementById("readContent").textContent = post.content;

  readModal.classList.add("show");
}

postForm.addEventListener("submit", event => {
  event.preventDefault();

  const existingId = postId.value;

  const postData = {
    title: titleInput.value.trim(),
    category: categoryInput.value,
    description: descriptionInput.value.trim(),
    content: contentInput.value.trim(),
    date: new Date().toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric"
    })
  };

  if (existingId) {
    const index = posts.findIndex(p => p.id === Number(existingId));

    if (index !== -1) {
      posts[index] = {
        ...posts[index],
        ...postData
      };
    }
  } else {
    posts.unshift({
      id: Date.now(),
      ...postData
    });
  }

  savePosts();
  renderPosts();
  postModal.classList.remove("show");
  postForm.reset();
});

adminBtn.addEventListener("click", openNewPost);
closeModal.addEventListener("click", () => postModal.classList.remove("show"));
closeReadModal.addEventListener("click", () => readModal.classList.remove("show"));

window.addEventListener("click", event => {
  if (event.target === postModal) postModal.classList.remove("show");
  if (event.target === readModal) readModal.classList.remove("show");
});

searchInput.addEventListener("input", renderPosts);

categoryButtons.forEach(button => {
  button.addEventListener("click", () => {
    categoryButtons.forEach(btn => btn.classList.remove("active"));
    button.classList.add("active");
    selectedCategory = button.dataset.category;
    renderPosts();
  });
});

themeBtn.addEventListener("click", () => {
  document.body.classList.toggle("dark");
  themeBtn.textContent =
    document.body.classList.contains("dark") ? "☀️" : "🌙";
});

renderPosts();
